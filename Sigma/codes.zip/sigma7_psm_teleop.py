"""
Use a Force Dimension sigma.7 to teleoperate the MuJoCo dVRK PSM model on Windows.

Run from the project root:
    python Sigma/sigma7_psm_teleop.py

If the SDK DLLs are not on PATH, pass the directory containing dhd64.dll/drd64.dll:
    python Sigma/sigma7_psm_teleop.py --sdk-bin "C:\\Program Files\\Force Dimension\\sdk-3.17.6\\bin"

Controls:
    q       quit
    r       reset the sigma.7 neutral pose and PSM home target
"""
from __future__ import annotations

import argparse
import ctypes
import math
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np


mujoco = None


PROJECT_DIR = Path(__file__).resolve().parents[1]
DEFAULT_XML = PROJECT_DIR / "Assest" / "psm_official" / "psm_control.xml"
LOCAL_SDK_DIR = Path(__file__).resolve().parent / "sdk-3.17.6"

CONTROL_JOINTS = ("yaw", "pitch", "insertion", "roll", "wrist_pitch", "wrist_yaw")
JAW_JOINT = "jaw"
EE_BODY = "tool_tip"


def _dll_names() -> tuple[str, str]:
    return ("dhd64.dll", "drd64.dll") if ctypes.sizeof(ctypes.c_void_p) == 8 else ("dhd.dll", "drd.dll")


def _candidate_sdk_dirs(explicit: str | None) -> list[Path | None]:
    candidates: list[Path | None] = []
    if explicit:
        candidates.append(Path(explicit))

    for env_name in ("FDSDK", "FORCE_DIMENSION_SDK", "FORCEDIMENSION_SDK"):
        value = os.environ.get(env_name)
        if value:
            root = Path(value)
            candidates.extend([root / "bin", root])

    candidates.extend([
        LOCAL_SDK_DIR / "bin",
        Path(r"C:\Program Files\Force Dimension\sdk-3.17.6\bin"),
        Path(r"C:\Program Files (x86)\Force Dimension\sdk-3.17.6\bin"),
        Path(r"C:\Force Dimension\sdk-3.17.6\bin"),
        None,  # Let the Windows loader search PATH.
    ])
    return candidates


def _find_sdk_bin(explicit: str | None) -> Path | None:
    dhd_name, drd_name = _dll_names()

    for candidate in _candidate_sdk_dirs(explicit):
        if candidate is None:
            continue
        if (candidate / dhd_name).exists() and (candidate / drd_name).exists():
            return candidate

    for root in (LOCAL_SDK_DIR, Path(r"C:\Program Files\Force Dimension"), Path(r"C:\Force Dimension")):
        if not root.exists():
            continue
        for dhd_path in root.rglob(dhd_name):
            candidate = dhd_path.parent
            if (candidate / drd_name).exists():
                return candidate

    return None


class ForceDimensionSDK:
    """Small ctypes wrapper for the SDK functions used by this teleop script."""

    DHD_ON = 1
    DHD_OFF = 0
    DEFAULT_DEVICE_ID = ctypes.c_byte(-1)

    def __init__(self, sdk_bin: str | None = None, use_drd_init: bool = True) -> None:
        self.sdk_bin = _find_sdk_bin(sdk_bin)
        self._dll_dir_handle = None
        if sys.platform == "win32" and self.sdk_bin is not None:
            self._dll_dir_handle = os.add_dll_directory(str(self.sdk_bin))

        dhd_name, drd_name = _dll_names()
        loader = ctypes.WinDLL if sys.platform == "win32" else ctypes.CDLL
        try:
            dhd_path = str(self.sdk_bin / dhd_name) if self.sdk_bin else dhd_name
            drd_path = str(self.sdk_bin / drd_name) if self.sdk_bin else drd_name
            self.dhd = loader(dhd_path)
            self.drd = loader(drd_path)
        except OSError as exc:
            searched = "\n  ".join(str(p) for p in _candidate_sdk_dirs(sdk_bin) if p is not None)
            raise RuntimeError(
                f"Could not load Force Dimension SDK DLLs ({dhd_name}, {drd_name}).\n"
                f"Pass --sdk-bin or add the SDK bin directory to PATH.\nSearched:\n  {searched}"
            ) from exc

        self._configure_signatures()
        self._opened = False
        self._use_drd_init = use_drd_init
        self._force_output_enabled = False
        self.device_id = self.DEFAULT_DEVICE_ID

    def _configure_signatures(self) -> None:
        c_byte = ctypes.c_byte
        c_bool = ctypes.c_bool
        c_double = ctypes.c_double
        c_int = ctypes.c_int
        c_ubyte = ctypes.c_ubyte

        self.dhd.dhdOpen.restype = c_int
        self.dhd.dhdGetDeviceID.restype = c_int
        self.dhd.dhdClose.argtypes = [c_byte]
        self.dhd.dhdClose.restype = c_int
        self.dhd.dhdErrorGetLastStr.restype = ctypes.c_char_p
        self.dhd.dhdGetComFreq.argtypes = [c_byte]
        self.dhd.dhdGetComFreq.restype = c_double
        self.dhd.dhdGetTime.restype = c_double
        self.dhd.dhdSleep.argtypes = [c_double]
        self.dhd.dhdEnableForce.argtypes = [c_ubyte, c_byte]
        self.dhd.dhdEnableForce.restype = c_int
        self.dhd.dhdSetGravityCompensation.argtypes = [c_int, c_byte]
        self.dhd.dhdSetGravityCompensation.restype = c_int
        self.dhd.dhdGetGripperAngleDeg.argtypes = [ctypes.POINTER(c_double), c_byte]
        self.dhd.dhdGetGripperAngleDeg.restype = c_int
        self.dhd.dhdGetLinearVelocity.argtypes = [
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            c_byte,
        ]
        self.dhd.dhdGetLinearVelocity.restype = c_int
        self.dhd.dhdGetPositionAndOrientationFrame.argtypes = [
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            c_byte,
        ]
        self.dhd.dhdGetPositionAndOrientationFrame.restype = c_int
        self.dhd.dhdSetForceAndTorqueAndGripperForce.argtypes = [
            c_double,
            c_double,
            c_double,
            c_double,
            c_double,
            c_double,
            c_double,
            c_byte,
        ]
        self.dhd.dhdSetForceAndTorqueAndGripperForce.restype = c_int

        self.drd.drdOpen.restype = c_int
        self.drd.drdGetDeviceID.restype = c_int
        self.drd.drdClose.argtypes = [c_byte]
        self.drd.drdClose.restype = c_int
        self.drd.drdIsInitialized.argtypes = [c_byte]
        self.drd.drdIsInitialized.restype = c_bool
        self.drd.drdAutoInit.argtypes = [c_byte]
        self.drd.drdAutoInit.restype = c_int
        self.drd.drdStart.argtypes = [c_byte]
        self.drd.drdStart.restype = c_int
        self.drd.drdGetCtrlFreq.argtypes = [c_byte]
        self.drd.drdGetCtrlFreq.restype = c_double
        self.drd.drdGetPositionAndOrientation.argtypes = [
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            c_byte,
        ]
        self.drd.drdGetPositionAndOrientation.restype = c_int
        self.drd.drdGetVelocity.argtypes = [
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            ctypes.POINTER(c_double),
            c_byte,
        ]
        self.drd.drdGetVelocity.restype = c_int
        self.drd.drdStop.argtypes = [c_bool, c_byte]
        self.drd.drdStop.restype = c_int
        self.drd.drdMoveToPos.argtypes = [c_double, c_double, c_double, c_bool, c_byte]
        self.drd.drdMoveToPos.restype = c_int
        self.drd.drdMoveToRot.argtypes = [c_double, c_double, c_double, c_bool, c_byte]
        self.drd.drdMoveToRot.restype = c_int

    def error(self) -> str:
        raw = self.dhd.dhdErrorGetLastStr()
        return raw.decode("utf-8", errors="replace") if raw else "unknown SDK error"

    def _check(self, code: int, action: str) -> None:
        if code < 0:
            raise RuntimeError(f"{action} failed: {self.error()}")

    def _set_device_id(self, device_id: int) -> None:
        if device_id >= 0:
            self.device_id = ctypes.c_byte(device_id)

    def _enable_optional_device_features(self) -> None:
        gravity_result = self.dhd.dhdSetGravityCompensation(self.DHD_ON, self.device_id)
        if gravity_result < 0:
            print(f"Warning: gravity compensation unavailable: {self.error()}")

        force_result = self.dhd.dhdEnableForce(self.DHD_ON, self.device_id)
        if force_result < 0:
            print(f"Warning: force output unavailable; continuing read-only: {self.error()}")
            self._force_output_enabled = False
        else:
            self._force_output_enabled = True

    def open(self) -> None:
        if self._use_drd_init:
            self._check(self.drd.drdOpen(), "drdOpen")
            self._opened = True
            self._set_device_id(self.drd.drdGetDeviceID())
            if not self.drd.drdIsInitialized(self.device_id):
                self._check(self.drd.drdAutoInit(self.device_id), "drdAutoInit")
            self._check(self.drd.drdStart(self.device_id), "drdStart")
            self._check(self.drd.drdMoveToPos(0.0, 0.0, 0.0, True, self.device_id), "drdMoveToPos")
            self._check(self.drd.drdMoveToRot(0.0, 0.0, 0.0, True, self.device_id), "drdMoveToRot")
            self._check(self.drd.drdStop(True, self.device_id), "drdStop")
            self._set_device_id(self.drd.drdGetDeviceID())
        else:
            self._check(self.dhd.dhdOpen(), "dhdOpen")
            self._opened = True
            self._set_device_id(self.dhd.dhdGetDeviceID())

        self._enable_optional_device_features()

    def close(self) -> None:
        if not self._opened:
            return
        try:
            self.set_zero_force()
            if self._force_output_enabled:
                self.dhd.dhdEnableForce(self.DHD_OFF, self.device_id)
            self.dhd.dhdClose(self.device_id)
            self.drd.drdClose(self.device_id)
        finally:
            self._opened = False
            self._force_output_enabled = False

    def set_zero_force(self) -> None:
        if not self._force_output_enabled:
            return
        self.dhd.dhdSetForceAndTorqueAndGripperForce(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, self.device_id)

    def read_state(self) -> tuple[np.ndarray, np.ndarray, float, np.ndarray]:
        state = self._read_state_dhd()
        if state is not None:
            return state

        state = self._read_state_drd()
        if state is not None:
            return state

        raise RuntimeError(f"Could not read device state with DHD or DRD: {self.error()}")

    def _read_state_dhd(self) -> tuple[np.ndarray, np.ndarray, float, np.ndarray] | None:
        px = ctypes.c_double()
        py = ctypes.c_double()
        pz = ctypes.c_double()
        matrix_buffer = (ctypes.c_double * 9)()
        result = self.dhd.dhdGetPositionAndOrientationFrame(
            ctypes.byref(px),
            ctypes.byref(py),
            ctypes.byref(pz),
            matrix_buffer,
            self.device_id,
        )
        if result < 0:
            return None

        gripper = ctypes.c_double()
        if self.dhd.dhdGetGripperAngleDeg(ctypes.byref(gripper), self.device_id) < 0:
            gripper.value = 0.0

        vx = ctypes.c_double()
        vy = ctypes.c_double()
        vz = ctypes.c_double()
        if self.dhd.dhdGetLinearVelocity(ctypes.byref(vx), ctypes.byref(vy), ctypes.byref(vz), self.device_id) < 0:
            vx.value = vy.value = vz.value = 0.0

        position = np.array([px.value, py.value, pz.value], dtype=float)
        rotation = np.array(matrix_buffer, dtype=float).reshape(3, 3)
        linear_velocity = np.array([vx.value, vy.value, vz.value], dtype=float)
        return position, rotation, float(gripper.value), linear_velocity

    def _read_state_drd(self) -> tuple[np.ndarray, np.ndarray, float, np.ndarray] | None:
        px = ctypes.c_double()
        py = ctypes.c_double()
        pz = ctypes.c_double()
        oa = ctypes.c_double()
        ob = ctypes.c_double()
        og = ctypes.c_double()
        pg = ctypes.c_double()
        matrix_buffer = (ctypes.c_double * 9)()
        result = self.drd.drdGetPositionAndOrientation(
            ctypes.byref(px),
            ctypes.byref(py),
            ctypes.byref(pz),
            ctypes.byref(oa),
            ctypes.byref(ob),
            ctypes.byref(og),
            ctypes.byref(pg),
            matrix_buffer,
            self.device_id,
        )
        if result < 0:
            return None

        vx = ctypes.c_double()
        vy = ctypes.c_double()
        vz = ctypes.c_double()
        wx = ctypes.c_double()
        wy = ctypes.c_double()
        wz = ctypes.c_double()
        vg = ctypes.c_double()
        velocity_result = self.drd.drdGetVelocity(
            ctypes.byref(vx),
            ctypes.byref(vy),
            ctypes.byref(vz),
            ctypes.byref(wx),
            ctypes.byref(wy),
            ctypes.byref(wz),
            ctypes.byref(vg),
            self.device_id,
        )
        if velocity_result < 0:
            vx.value = vy.value = vz.value = 0.0

        position = np.array([px.value, py.value, pz.value], dtype=float)
        rotation = np.array(matrix_buffer, dtype=float).reshape(3, 3)
        linear_velocity = np.array([vx.value, vy.value, vz.value], dtype=float)
        return position, rotation, math.degrees(pg.value), linear_velocity

    def com_freq(self) -> float:
        freq = float(self.dhd.dhdGetComFreq(self.device_id))
        if freq > 0.0:
            return freq
        return float(self.drd.drdGetCtrlFreq(self.device_id))


@dataclass
class TeleopCalibration:
    master_position: np.ndarray
    master_rotation: np.ndarray
    target_position_home: np.ndarray
    target_rotation_home: np.ndarray
    ctrl_home: np.ndarray


def rotation_error(current: np.ndarray, desired: np.ndarray) -> np.ndarray:
    return 0.5 * (
        np.cross(current[:, 0], desired[:, 0])
        + np.cross(current[:, 1], desired[:, 1])
        + np.cross(current[:, 2], desired[:, 2])
    )


def clip_norm(vector: np.ndarray, max_norm: float) -> np.ndarray:
    norm = float(np.linalg.norm(vector))
    if norm > max_norm > 0.0:
        return vector * (max_norm / norm)
    return vector


def body_rotation(data: mujoco.MjData, body_id: int) -> np.ndarray:
    return data.xmat[body_id].reshape(3, 3).copy()


def controlled_dof_columns(model: mujoco.MjModel, joint_names: tuple[str, ...]) -> list[int]:
    columns: list[int] = []
    for name in joint_names:
        joint_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, name)
        if joint_id < 0:
            raise ValueError(f"MuJoCo joint not found: {name}")
        columns.append(int(model.jnt_dofadr[joint_id]))
    return columns


def actuator_ids(model: mujoco.MjModel, joint_names: tuple[str, ...]) -> list[int]:
    ids: list[int] = []
    for name in joint_names:
        actuator_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, f"ctrl_{name}")
        if actuator_id < 0:
            raise ValueError(f"MuJoCo actuator not found: ctrl_{name}")
        ids.append(actuator_id)
    return ids


def actuator_home_from_qpos(model: mujoco.MjModel, data: mujoco.MjData, joint_names: tuple[str, ...]) -> np.ndarray:
    values = []
    for name in joint_names:
        joint_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, name)
        qpos_address = int(model.jnt_qposadr[joint_id])
        values.append(float(data.qpos[qpos_address]))
    return np.array(values, dtype=float)


def compute_ik_step(
    model: mujoco.MjModel,
    data: mujoco.MjData,
    ee_body_id: int,
    dof_columns: list[int],
    target_position: np.ndarray,
    target_rotation: np.ndarray,
    damping: float,
    orientation_gain: float,
    max_position_error: float,
    max_step: float,
) -> np.ndarray:
    current_position = data.xpos[ee_body_id].copy()
    current_rotation = body_rotation(data, ee_body_id)

    position_error = clip_norm(target_position - current_position, max_position_error)
    angular_error = orientation_gain * rotation_error(current_rotation, target_rotation)
    task_error = np.concatenate([position_error, angular_error])

    jacp = np.zeros((3, model.nv))
    jacr = np.zeros((3, model.nv))
    mujoco.mj_jacBody(model, data, jacp, jacr, ee_body_id)
    jacobian = np.vstack([jacp[:, dof_columns], jacr[:, dof_columns]])
    regularized = jacobian @ jacobian.T + damping * np.eye(6)
    dq = jacobian.T @ np.linalg.solve(regularized, task_error)
    return clip_norm(dq, max_step)


def make_calibration(
    device: ForceDimensionSDK,
    model: mujoco.MjModel,
    data: mujoco.MjData,
    ee_body_id: int,
    arm_actuators: list[int],
    jaw_actuator: int,
) -> TeleopCalibration:
    master_position, master_rotation, _, _ = device.read_state()
    mujoco.mj_forward(model, data)

    ctrl_home = data.ctrl.copy()
    data.ctrl[arm_actuators] = actuator_home_from_qpos(model, data, CONTROL_JOINTS)
    jaw_home = actuator_home_from_qpos(model, data, (JAW_JOINT,))[0]
    data.ctrl[jaw_actuator] = jaw_home

    return TeleopCalibration(
        master_position=master_position,
        master_rotation=master_rotation,
        target_position_home=data.xpos[ee_body_id].copy(),
        target_rotation_home=body_rotation(data, ee_body_id),
        ctrl_home=ctrl_home.copy(),
    )


def keyboard_command() -> str | None:
    if sys.platform != "win32":
        return None
    import msvcrt

    if not msvcrt.kbhit():
        return None
    key = msvcrt.getwch()
    if key in ("\x00", "\xe0") and msvcrt.kbhit():
        key = msvcrt.getwch()
    return key.lower()


def gripper_to_jaw(gripper_deg: float, close_deg: float, open_deg: float, jaw_range: np.ndarray) -> float:
    if math.isclose(open_deg, close_deg):
        normalized = 0.0
    else:
        normalized = (gripper_deg - close_deg) / (open_deg - close_deg)
    normalized = float(np.clip(normalized, 0.0, 1.0))
    return float(jaw_range[0] + normalized * (jaw_range[1] - jaw_range[0]))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Teleoperate the MuJoCo dVRK PSM with a Force Dimension sigma.7")
    parser.add_argument("--xml", default=str(DEFAULT_XML), help="Path to the MuJoCo PSM XML")
    parser.add_argument("--sdk-bin", default=None, help="Directory containing dhd64.dll and drd64.dll")
    parser.add_argument("--no-drd-init", action="store_true", help="Skip DRD auto-init and only use DHD open/read calls")
    parser.add_argument("--scale-x", type=float, default=1.8, help="Master X meters to MuJoCo world X meters")
    parser.add_argument("--scale-y", type=float, default=1.8, help="Master Y meters to MuJoCo world Y meters")
    parser.add_argument("--scale-z", type=float, default=1.8, help="Master Z meters to MuJoCo world Z meters")
    parser.add_argument("--damping", type=float, default=1e-3, help="Damped least-squares IK damping")
    parser.add_argument("--orientation-gain", type=float, default=0.25, help="IK orientation error gain")
    parser.add_argument("--max-position-error", type=float, default=0.004, help="Max Cartesian IK correction per frame")
    parser.add_argument("--max-joint-step", type=float, default=0.004, help="Max arm joint target update per frame")
    parser.add_argument("--gripper-close-deg", type=float, default=0.0, help="sigma.7 gripper angle treated as closed")
    parser.add_argument("--gripper-open-deg", type=float, default=30.0, help="sigma.7 gripper angle treated as open")
    parser.add_argument("--print-every", type=float, default=0.25, help="Status print period in seconds")
    return parser.parse_args()


def main() -> None:
    global mujoco

    args = parse_args()
    xml_path = Path(args.xml)
    if not xml_path.exists():
        raise FileNotFoundError(f"MuJoCo XML not found: {xml_path}")

    try:
        import mujoco as mujoco_module
        import mujoco.viewer
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "The active Python environment does not have the 'mujoco' package. "
            "Install it with 'pip install mujoco' or run this script from the Conda/Python "
            "environment you use for the existing MuJoCo examples."
        ) from exc

    mujoco = mujoco_module
    model = mujoco.MjModel.from_xml_path(str(xml_path))
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)

    ee_body_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, EE_BODY)
    if ee_body_id < 0:
        raise ValueError(f"MuJoCo body not found: {EE_BODY}")

    arm_actuators = actuator_ids(model, CONTROL_JOINTS)
    jaw_actuator = actuator_ids(model, (JAW_JOINT,))[0]
    arm_dof_columns = controlled_dof_columns(model, CONTROL_JOINTS)
    arm_ctrl_range = model.actuator_ctrlrange[arm_actuators]
    jaw_ctrl_range = model.actuator_ctrlrange[jaw_actuator]
    scale = np.array([args.scale_x, args.scale_y, args.scale_z], dtype=float)

    device = ForceDimensionSDK(args.sdk_bin, use_drd_init=not args.no_drd_init)
    try:
        print("Opening sigma.7...")
        device.open()
        calibration = make_calibration(device, model, data, ee_body_id, arm_actuators, jaw_actuator)

        print(f"Loaded MuJoCo XML: {xml_path}")
        print(f"SDK DLL directory: {device.sdk_bin if device.sdk_bin else 'PATH'}")
        print("Move the sigma.7 to control the PSM. Press r to recalibrate, q to quit.")

        last_print = time.perf_counter()
        with mujoco.viewer.launch_passive(model, data) as viewer:
            while viewer.is_running():
                command = keyboard_command()
                if command == "q":
                    break
                if command == "r":
                    calibration = make_calibration(device, model, data, ee_body_id, arm_actuators, jaw_actuator)
                    print("\nRecalibrated neutral pose.")

                master_position, master_rotation, gripper_deg, _ = device.read_state()
                device.set_zero_force()

                master_delta = (master_position - calibration.master_position) * scale
                target_position = calibration.target_position_home + master_delta

                master_rotation_delta = master_rotation @ calibration.master_rotation.T
                target_rotation = calibration.target_rotation_home @ master_rotation_delta

                dq = compute_ik_step(
                    model=model,
                    data=data,
                    ee_body_id=ee_body_id,
                    dof_columns=arm_dof_columns,
                    target_position=target_position,
                    target_rotation=target_rotation,
                    damping=args.damping,
                    orientation_gain=args.orientation_gain,
                    max_position_error=args.max_position_error,
                    max_step=args.max_joint_step,
                )
                next_arm_ctrl = data.ctrl[arm_actuators] + dq
                data.ctrl[arm_actuators] = np.clip(next_arm_ctrl, arm_ctrl_range[:, 0], arm_ctrl_range[:, 1])
                data.ctrl[jaw_actuator] = gripper_to_jaw(
                    gripper_deg,
                    args.gripper_close_deg,
                    args.gripper_open_deg,
                    jaw_ctrl_range,
                )

                mujoco.mj_step(model, data)
                viewer.sync()

                now = time.perf_counter()
                if now - last_print >= args.print_every:
                    last_print = now
                    tcp = data.xpos[ee_body_id]
                    print(
                        "\r"
                        f"sigma=({master_position[0]:+.3f},{master_position[1]:+.3f},{master_position[2]:+.3f}) m "
                        f"tcp=({tcp[0]:+.3f},{tcp[1]:+.3f},{tcp[2]:+.3f}) m "
                        f"grip={gripper_deg:5.1f} deg "
                        f"freq={device.com_freq():.2f} kHz",
                        end="",
                        flush=True,
                    )
    finally:
        device.close()
        print("\nDevice closed.")


if __name__ == "__main__":
    main()
